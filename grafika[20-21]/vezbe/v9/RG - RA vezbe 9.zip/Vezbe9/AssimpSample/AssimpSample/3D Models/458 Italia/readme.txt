--------------------------------  FERRARI 458 ITALIA  --------------------------------


>>> FREE FOR PRIVATE USE <<<

>>> IT IS FORBIDDEN TO RESELL THESE MODEL <<<


DO NOT sell, resell, and distribute this model in any form / media 
without permission !
DO NOT Provide any free download of this model in any web site or
electronic devices without permission !
DO NOT remove text from this model !


.....................................All rights reserved.....................................


LightWave version Downloaded from DMI   www.dmi-3d.net
        www.dmi3d.com  -  http://dmi.chez-alice.fr/