//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by matrixModelView.rc
//
#define IDD_FORMVIEW                    101
#define IDT_TIMER                       101
#define IDR_MENU_MAIN                   101
#define IDD_ABOUT                       102
#define IDB_BITMAP_SONGHO               103
#define IDI_ICON1                       106
#define IDC_M_MV_0                      1001
#define IDC_M_MV_1                      1002
#define IDC_M_MV_2                      1003
#define IDC_M_MV_3                      1004
#define IDC_M_MV_4                      1005
#define IDC_M_MV_5                      1006
#define IDC_M_MV_6                      1007
#define IDC_M_MV_7                      1008
#define IDC_M_MV_8                      1009
#define IDC_M_MV_9                      1010
#define IDC_M_MV_10                     1011
#define IDC_M_MV_11                     1012
#define IDC_M_MV_12                     1013
#define IDC_M_MV_13                     1014
#define IDC_M_MV_14                     1015
#define IDC_M_MV_15                     1016
#define IDC_M_V_0                       1017
#define IDC_M_V_1                       1018
#define IDC_M_V_2                       1019
#define IDC_M_V_3                       1020
#define IDC_M_V_4                       1021
#define IDC_M_V_5                       1022
#define IDC_M_V_6                       1023
#define IDC_M_V_7                       1024
#define IDC_M_V_8                       1025
#define IDC_M_V_9                       1026
#define IDC_M_V_10                      1027
#define IDC_M_V_11                      1028
#define IDC_M_V_12                      1029
#define IDC_M_V_13                      1030
#define IDC_M_V_14                      1031
#define IDC_M_V_15                      1032
#define IDC_M_M_0                       1033
#define IDC_M_M_1                       1034
#define IDC_M_M_2                       1035
#define IDC_M_M_3                       1036
#define IDC_M_M_4                       1037
#define IDC_M_M_5                       1038
#define IDC_M_M_6                       1039
#define IDC_M_M_7                       1040
#define IDC_M_M_8                       1041
#define IDC_M_M_9                       1042
#define IDC_M_M_10                      1043
#define IDC_M_M_11                      1044
#define IDC_M_M_12                      1045
#define IDC_M_M_13                      1046
#define IDC_M_M_14                      1047
#define IDC_M_M_15                      1048
#define IDC_SPIN_VIEW_X                 1050
#define IDC_EDIT_VIEW_X                 1051
#define IDC_EDIT_HEADING                1052
#define IDC_EDIT_PITCH                  1053
#define IDC_SPIN_HEADING                1054
#define IDC_SPIN_PITCH                  1055
#define IDC_EDIT_VIEW_Y                 1056
#define IDC_BUTTON_VIEW_RESET           1057
#define IDC_EDIT_POSITION_X             1058
#define IDC_EDIT_POSITION_Y             1059
#define IDC_EDIT_POSITION_Z             1060
#define IDC_EDIT_ROTATION_X             1061
#define IDC_EDIT_ROTATION_Y             1062
#define IDC_EDIT_ROTATION_Z             1063
#define IDC_SPIN_POSITION_X             1064
#define IDC_SPIN_POSITION_Y             1065
#define IDC_SPIN_POSITION_Z             1066
#define IDC_SPIN_ROTATION_X             1067
#define IDC_SPIN_ROTATION_Y             1068
#define IDC_SPIN_ROTATION_Z             1069
#define IDC_BUTTON_MODEL_RESET          1070
#define IDC_EDIT_VIEW_Z                 1071
#define IDC_SPIN_VIEW_Y                 1072
#define IDC_SPIN_VIEW_Z                 1073
#define IDC_EDIT_ROLL                   1074
#define IDC_SPIN_ROLL                   1075
#define IDC_VIEW_GL                     1076
#define IDC_MODEL_GL                    1077
#define ID_OK                           1077
#define IDC_OK                          1077
#define ID_FILE_EXIT                    40001
#define ID_HELP_ABOUT                   40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1078
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
